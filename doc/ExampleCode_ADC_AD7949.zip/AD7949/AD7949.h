/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia)

 Date :	Jan,2013 

 File name : AD7949.h

 Description : Use the SPI(simulated by ADuC7026 GPIO) to communicate with AD7949

 Hardware plateform : ADuC7026 Eval Board Rev.B1 and EVAL-AD7949EDZ 	
********************************************************************************/

#ifndef _AD7949_H_
#define _AD7949_H_


#define CFG_KEEP				0x0
#define CFG_OVERWRITE			0x2000

#define INCC_BIPOLAR_DIFFERENTIAL_PAIRS		0x0
#define INCC_BIPOLAR						0x800
#define INCC_TEMPERATURE_SENSOR				0xC00
#define INCC_UNIPOLAR_DIFFERENTIAL_PAIRS	0x1000
#define INCC_UNIPOLAR_TO_COM				0x1800
#define INCC_UNIPOLAR_TO_GND				0x1C00

#define IN0									0x0
#define IN1									0x80
#define IN2									0x100
#define IN3									0x180
#define IN4									0x200
#define IN5									0x280
#define IN6									0x300
#define IN7									0x380

#define BW_0_25								0x0
#define BW_FULL								0x40

#define REF_IN_2V5							0x0
#define REF_IN_4V096						0x8
#define REF_EX_TEM_ENABLE					0x10
#define REF_EX_IN_BUFFER_TEM_ENABLE			0x18
#define REF_EX_TEM_DISABLE					0x30
#define REF_EX_IN_BUFFER_TEM_DISABLE		0x38

#define SEQ_DISABLE							0x0
#define SEQ_UPDATA_CONFIGURATION_DURING_SEQUENCE	0x2
#define SEQ_SCAN_TEM								0x4
#define SEQ_SCAN									0x6

#define RB_DISABLE									0x0
#define RB_ENABLE									0x1				


#define SET_CS()		GP2DAT = (GP2DAT | 0x00800000)	//P2.7->/CS
#define CLR_CS()		GP2DAT = (GP2DAT & 0xFF7FFFFF)

#define	SET_SCL()		GP1DAT = (GP1DAT | 0x00100000)	//P1.4->SCLK
#define	CLR_SCL()		GP1DAT = (GP1DAT & 0xffEFffff)

#define SET_SDO()		GP1DAT = (GP1DAT | 0x00400000)	//P1.6->SDO
#define CLR_SDO()		GP1DAT = (GP1DAT & 0xffBFffff)	

void AD7949_reg_write(unsigned int RegisterData );
unsigned int AD7949_data_read(void );

#endif
