/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia)

 Date :	Jan,2013 

 File name : ADuC7026Driver.c

 Description : Use the SPI(simulated by ADuC7026 GPIO) to communicate with AD7949

 Hardware plateform : ADuC7026 Eval Board Rev.B1 and EVAL-AD7949EDZ 	
********************************************************************************/

#include "ADuC7026.h"
#include "ADuC7026Driver.h"

/*    Function Pointers for Interrupts  */
// Copied from irq_arm.c in Keil uV4, required 
tyVctHndlr    IRQ     = (tyVctHndlr)0x0;
tyVctHndlr    SWI     = (tyVctHndlr)0x0;
tyVctHndlr    FIQ     = (tyVctHndlr)0x0;
tyVctHndlr    UNDEF   = (tyVctHndlr)0x0;
tyVctHndlr    PABORT  = (tyVctHndlr)0x0;
tyVctHndlr    DABORT  = (tyVctHndlr)0x0;

void	IRQ_Handler   (void) __irq;
void	SWI_Handler   (void) __irq;
void	FIQ_Handler   (void) __irq;
void	Undef_Handler (void) __irq;
void	PAbt_Handler  (void) __irq;
void	DAbt_Handler  (void) __irq;

void	IRQ_Handler(void) __irq
{
	if ( *IRQ !=0x00)
	{
		IRQ();
	}
}

void	FIQ_Handler(void) __irq
{
	if ( *FIQ !=0x00)
	{
		FIQ();
	}
}

void	SWI_Handler(void) __irq
{
	if ( *SWI !=0x00)
	{
		SWI();
	}
}

void	Undef_Handler(void)__irq 
{
	if ( *UNDEF !=0x00)
	{
		UNDEF();
	}
}

void	PAbt_Handler(void) __irq
{
	if ( *PABORT !=0x00)
	{
		PABORT();
	}
}

void	DAbt_Handler(void) __irq
{
	if ( *DABORT !=0x00)
	{
		DABORT();
	}
}
/*    Function Pointers for Interrupts  */

// add the c file here
/*******************************************************************
*   Function:    putchar
*   Description: Write character to Serial Port.
*******************************************************************/
void putchar(unsigned char ch)  
{          
	COMTX = ch;				 //COMTX is an 8-bit transmit register.
    while(!(0x020==(COMSTA0 & 0x020)))
    {
		;
	}
}


/*******************************************************************
*   Function:    ADuC7026_Initiate
*   Description: Configure clock and GPIO
*******************************************************************/
void ADuC7026_Initiate(void)
{
//  PLL SETTING  Clock 41.78MHz
	POWKEY1 = 0x01;				//Start PLL setting
	POWCON = 0x00;				//Set PLL active mode with CD = 0
	POWKEY2 = 0xF4;				//Finish PLL setting

//  GPIO SETTING  

	GP1CON = 0x00000011;		//CONFIG P1.6 P1.5 P1.4  as GPIO  P1.1 P1.O  as com
	GP2CON = 0x00000000;		//CONFIG P1.7 as GPIO

	GP2DAT = 0xE0E00000;		//P2.7 (CS4)  P2.6(CS2) P2.5(CS1) HIGH
	GP1DAT = 0xD0D00000;		//P1.6 SDO,P1.5 SDI,P1.4 SCLK  LOW	 P1.7(CS3) HIGH

//UART Initial��Baud Rate = 9600
	COMCON0 = 0x80;  
	COMDIV0 = 0x88;    		
	COMDIV1 = 0x00;
	COMCON0 = 0x07;  	
}

/*******************************************************************
*   Function:    delay
*   Description: Delay about length*0.2us
*******************************************************************/
void delay (signed int length)
{
	while (length >0)
    	length--;
}

/*
*/
