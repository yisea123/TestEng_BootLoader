/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia)

 Date :	Jan,2013 

 File name : AD7949.c

 Description : Use the SPI(simulated by ADuC7026 GPIO) to communicate with AD7949

 Hardware plateform : ADuC7026 Eval Board Rev.B1 and EVAL-AD7949EDZ 	
********************************************************************************/

#include "ADuC7026.h"	
#include "ADuC7026Driver.h"
#include "AD7949.h"


/*******************************************************************
*   Function:    AD7949_reg_write
*   Description: writes to the AD7949 via the SPI port.
*******************************************************************/
void AD7949_reg_write(unsigned int RegisterData)
{
	unsigned int ControlValue = 0;
	unsigned int i = 0;

	//Create the 14-bit 
	ControlValue = RegisterData;

	
	SET_CS();
	CLR_SCL();
	delay(3);
	CLR_CS();	 //bring CS low
	delay(3);


	//Write out the control word
	for(i=0; i<14; i++)
	{
		CLR_SCL();
		if(0x2000 == (ControlValue & 0x2000))
		{
			SET_SDO();	  //Send one to SDO pin
		}
		else
		{
			CLR_SDO();	  //Send zero to SDO pin
		}
		delay(3);
		SET_SCL();
		delay(3);

		ControlValue <<= 1;	//Rotate data
	}
	// keep the digital pins quiet > 20ns
	delay(1);
	SET_CS();	//bring CS high again
	// keep the digital pins quiet > 10ns
	delay(1);
}

/*******************************************************************
*   Function:    AD7949_data_read
*   Description: read from the AD7949 via the SPI port.
*******************************************************************/
unsigned int AD7949_data_read(void )
{
	unsigned int ReceiveData = 0;
	unsigned int i = 0;
	unsigned int iTemp =0;

	//DIN must be held low while reading data out for Bit 13, or the CFG register begins updating again 
	CLR_SDO();

	
	SET_CS();
	CLR_SCL();
	delay(3);
	CLR_CS();	 //bring CS low
	delay(3);

	//Write out the control word
	for(i=0; i<14; i++)
	{
		ReceiveData <<= 1;	//Rotate data
		delay(3);
		SET_SCL();
		delay(3);
		//and read code
		iTemp = GP1DAT;											//Read SDI of AD7949
			if(0x00000020 == (iTemp & 0x00000020))			   //SDI  P1.5
			{
				ReceiveData |= 1;	
			}
		CLR_SCL();

	}
	// keep the digital pins quiet > 20ns
	delay(1);
	SET_CS();	//bring CS high again
	// keep the digital pins quiet > 10ns
	delay(1);
	return ReceiveData;
}


