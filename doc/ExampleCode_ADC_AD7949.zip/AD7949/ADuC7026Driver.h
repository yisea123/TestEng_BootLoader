/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia)

 Date :	Jan,2013 

 File name : ADuC7026Driver.h

 Description : Use the SPI(simulated by ADuC7026 GPIO) to communicate with AD7949

 Hardware plateform : ADuC7026 Eval Board Rev.B1 and EVAL-AD7949EDZ 	
********************************************************************************/

#ifndef ADUC7026_DRIVER_H
#define ADUC7026_DRIVER_H

// add the header file here
void delay (int length);

void ADuC7026_Initiate(void);
void putchar(unsigned char ch);
/*
*/

#endif





