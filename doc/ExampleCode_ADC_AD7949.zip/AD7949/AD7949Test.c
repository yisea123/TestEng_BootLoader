/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia)

 Date :	Jan,2013 

 File name : AD7949Test.c

 Description : Use the SPI(simulated by ADuC7026 GPIO) to communicate with AD7949

 Hardware plateform : ADuC7026 Eval Board Rev.B1 and EVAL-AD7949EDZ 	
********************************************************************************/

#include "ADuC7026.h"
#include "ADuC7026Driver.h"
#include "AD7949.h"


int main(void) 
{
	
	unsigned int send_data;
	unsigned char data;
	
	ADuC7026_Initiate();

	//AD7949_reg_write(0x3C48);

	//first write
	AD7949_reg_write(CFG_OVERWRITE | INCC_UNIPOLAR_TO_GND | IN0 | BW_FULL | REF_IN_4V096 | SEQ_DISABLE | RB_DISABLE);
	//secend write
	AD7949_reg_write(CFG_OVERWRITE | INCC_UNIPOLAR_TO_GND | IN0 | BW_FULL | REF_IN_4V096 | SEQ_DISABLE | RB_DISABLE);
	//third write
	AD7949_reg_write(CFG_OVERWRITE | INCC_UNIPOLAR_TO_GND | IN0 | BW_FULL | REF_IN_4V096 | SEQ_DISABLE | RB_DISABLE);

	

	send_data=AD7949_data_read();
	data=(send_data >> 8) & 0x3F;
	putchar(data);
	data=send_data & 0xFF;
	putchar(data);

	while(1)
    {	
		;
	}
}


